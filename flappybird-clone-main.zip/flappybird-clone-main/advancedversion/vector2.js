class Vector2 {
    constructor () {
        this.x;
        this.y;
    }
}